/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n,i,ele,pos;
    printf("enter the size of the array;");
    scanf("%d",&n);
    int a[n];
    
    printf("enter elements in array;");
    for (i=0;i<n;i++){
            scanf("%d",&a[i]);
    }
    printf("enter element and position;");
    scanf("%d %d",&ele,&pos);
    for (i=n-1;i>=pos;i--){
        a[i+1]=a[i];
    }
    a[pos]=ele;
    n++;
    for (i=0;i<n;i++)
       printf("%d",a[i]);

    return 0;
}
