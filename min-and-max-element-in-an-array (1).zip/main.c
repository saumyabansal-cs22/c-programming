/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n,i,min,max;
    printf("enter the size of the array;");
    scanf("%d",&n);
    int a[n];
    
    printf("enter elements in array;");
    for (i=0;i<n;i++){
            scanf("%d",&a[i]);
    }
    min=max=a[0];
    for (i=0;i<n;i++){
        if (min>a[i])
           min=a[i];
        if (max<a[i])
           max=a[i];
         
    }
    printf("minimum element of the array=%d\n",min);
    printf("maximum element of the array=%d",max);
    
    

    return 0;
}
