/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int n,i,j,f;
    printf("enter the size of the array;=");
    scanf("%d",&n);
    int a[n][n],c[n][n];
    for (i=0;i<n;i++){
        for (j=0;j<n;j++){
            scanf("%d",&a[i][j]);
        }}
    for (i=0;i<n;i++){
        for (j=0;j<n;j++){
            c[i][j]=a[j][i];
        }}
    f=1;
    for (i=0;i<n;i++){
        for (j=0;j<n;j++){
            if (a[i][j]!=c[i][j]){
               f=0;
               break;
            }
            /*else
               //printf("not symmentric;");
               f=0;*/
        }}
    if (f==1){
        printf("symmetric;");
        //break;
    }
    else
       printf("not symmetric;");
    
    
    return 0;
}
