/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<math.h>

void main()
{
   int a,b;
   float c;
   printf("Enter the value of a & b\n");
   scanf("%d%d",&a,&b);
   c=pow(a,b);
   printf("c=%f",c);
}
