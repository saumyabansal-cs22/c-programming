/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    
    int n,m,i,j,c=0,d=0;
    printf("enter the size of the array;=");
    scanf("%d %d",&n,&m);
    int a[n][m];
    for (i=0;i<n;i++){
        for (j=0;j<m;j++){
            scanf("%d",&a[i][j]);
        }}
    for (i=0;i<n;i++){
        for (j=0;j<m;j++){
            if (a[i][j]==0)
                c++;
            
            else
                d++;
       
    }}
    if (c>d){
       printf("sparse matrix;\n");
       for (i=0;i<n;i++){
        for (j=0;j<m;j++){
            printf("%d",a[i][j]);
        }
           printf("\n");
       }
    }
    else{
       printf("not sparse matrix\n");
        for (i=0;i<n;i++){
        for (j=0;j<m;j++){
            printf("%d ",a[i][j]);
        }
            printf("\n");
        }
    }


    return 0;
}
