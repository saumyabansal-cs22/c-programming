/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n,m,i,pos;
    printf("enter the size of the array;");
    scanf("%d",&n);
    int a[n];
    printf("enter number of elements;");
    scanf("%d",&m);
    
    printf("enter elements in array;");
    for (i=0;i<m;i++){
            scanf("%d",&a[i]);
    }
    printf("enter position;");
    scanf("%d",&pos);
    for (i=pos;i<m-1;i++ent)
        a[i]=a[i+1];
        m--;
   for (i=0;i<m;i++)
       printf("%d",a[i]);

    return 0;
}
