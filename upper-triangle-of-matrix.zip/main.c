/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int n,i,j;
    printf("enter the size of the array;=");
    scanf("%d",&n);
    int a[n][n];
    for (i=0;i<n;i++){
        for (j=0;j<n;j++){
            scanf("%d",&a[i][j]);
        }}
    for (i=0;i<n;i++){
        for (j=0;j<n;j++){
            if (i<=j){
                printf("%d",a[i][j]);
                
            }
            else
               printf(" ");
            
        
        }
        printf("\n");
    }


    return 0;
}

