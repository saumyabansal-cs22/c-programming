/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n,m,i,j;
    printf("enter the size of the array;=");
    scanf("%d %d",&n,&m);
    int a[n][m],b[n][m];
    int c[n][m];
    printf("enter elements for matrix A;\n");
    for (i=0;i<n;i++){
        for (j=0;j<m;j++){
            scanf("%d",&a[i][j]);
        }}
    printf("enter elements for matrix B;\n");
    for (i=0;i<n;i++){
        for (j=0;j<m;j++){
            scanf("%d",&b[i][j]);
        }}
    for (i=0;i<n;i++){
        for (j=0;j<m;j++){
           c[i][j]=a[i][j]-b[i][j];
        }}
    printf("array with sum of A & B;\n");
    for (i=0;i<n;i++){
        for (j=0;j<m;j++){
            printf("%d ",c[i][j]);

    }
    printf("\n");
    }

    return 0;
}
