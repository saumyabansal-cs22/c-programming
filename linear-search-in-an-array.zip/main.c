/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n;
    printf("enter the size of the array;");
    scanf("%d",&n);
    int a[n],ele,i,k,f=0;
    for (i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    printf("enter the element to be found");
    scanf("%d",&ele);
    for (i=0;i<n;i++)
    {
        if (a[i]==ele)
        {
            f=1;
            k=i+1;
            break;
        }
    }  
    if (f==1)
         printf("element found at position;=%d",k);
    else
        printf("not found");

    return 0;
}
